# JARVIS-voice-assistant
A voice assistant application capable of performing various tasks such as playing music, and providing information.
api key use to chat with ai.
in this program use paid api key use,  if you use free api key contect me on instagram = Keval_king_212
